﻿namespace TodoList.Core
{
    public static class Constants
    {
        public const string AdministratorRole = "Administrator";
        public const string UserRole = "User";

        public const int MAX_TAGS = 3;
    }
}
