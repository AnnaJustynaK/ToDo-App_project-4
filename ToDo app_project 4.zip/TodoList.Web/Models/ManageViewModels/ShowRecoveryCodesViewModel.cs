﻿using System.Collections.Generic;

namespace TodoList.Web.Models.ManageViewModels
{
    public class ShowRecoveryCodesViewModel
    {
        public IEnumerable<string> RecoveryCodes { get; set; }
    }
}
